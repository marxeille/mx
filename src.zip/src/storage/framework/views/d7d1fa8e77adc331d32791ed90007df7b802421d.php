<?php $__env->startSection('content'); ?>
<div class="container" >
    <div class="row">
        <!--box header-->
        <div class="box-header">
              <h3 class="box-title"><a href="<?php echo e(route('admin.items.dashboard')); ?>"><?php echo e(trans('label.administrator')); ?></a> > <b><?php echo e(trans('label.models')); ?></b></h3>
        </div>
        <!--end box header-->
        <!--box col-md-12-->
        <div class="col-md-12" style="margin-top:30px;">          
          <div class="box">            
          <!--box body-->
              <div class="box-body" style="background:white;">
              	<form method="post" class="form-inline" style="margin-top:30px;background:white;">
                 	  <?php echo e(csrf_field()); ?>

                  	<!--alert-->
                  	<?php if(session('alert')): ?>
                      <div id="message" class="alert alert-success"><?php echo e(session('alert')); ?></div>
                  	<?php endif; ?>
                  	<!--end alert-->
                  	<table id="itemTable" cellpadding="0" cellspacing="0" border="0" class="table table-bordered table-striped" width="100%">
                      <thead>
                        <tr>
                            <th>ID</th>
                            <th><?php echo e(trans('label.brands')); ?></th>
                            <th><?php echo e(trans('label.models')); ?></th>
                            <th><?php echo e(trans('label.added_by')); ?></th>
                            <th><?php echo e(trans('label.created_at')); ?></th>
                            <th><?php echo e(trans('label.active')); ?></th>
                            <th></th>
                        </tr>
                      </thead>
                      <thead>
                        <td class="width5percent"><input type="text" data-column="0"  class="search-input-text form-control width100percent"></td>
                        <td class="width8percent">
                            <select data-column="1"  class="search-input-select bs-filters form-control width100percent">
                            <option value=""></option>
                           <?php foreach($brands as $brand): ?>
                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                            <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="width10percent"><input type="text" data-column="2"  class="search-input-text form-control width100percent"></td>
                        <td class="width8percent">
                            <select data-column="3"  class="search-input-select bs-filters form-control width100percent">
                            <option value=""></option>
                           <?php foreach($employees as $employee): ?>
                            <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
                            <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="width12percent">
                            <input type="text" data-column="4" id="dayFrom" placeholder="<?php echo e(trans('label.from')); ?>"  class="search-input-date form-control width100percent">
                            <input type="text" data-column="4" id="dayTo" placeholder="<?php echo e(trans('label.to')); ?>" class="search-input-date form-control width100percent">
                        </td>
                        <td class="width8percent">
                            <select data-column="5"  class="search-input-select bs-filters form-control width100percent">
                            <option value=""> </option>
                            <option value="1"><?php echo e(trans('label.active')); ?></option>
                            <option value="0"><?php echo e(trans('label.inactive')); ?></option>
                            </select>
                        </td>
                        <td><p class="ban icon-center" id="clear"><i class="fa fa-times" aria-hidden="true"></i></p></td>
                      </thead>
                  	</table>
              	</form>
                <form class="new_brand form-inline" data-id=0 id="add_form" action="<?php echo e(route('admin.model.add')); ?>" method="POST" >
                    <?php echo e(csrf_field()); ?> 
                    <select  name="id_brand" id="brand_select" data-column="1"  class=" bs-filters form-control col-md-3 width8percent">
                        <option value="" disabled selected><?php echo e(trans('label.brands')); ?></option>
                        <?php foreach($brands as $brand): ?>
                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                        <?php endforeach; ?>
                    </select> 
                    <input type="text" placeholder="<?php echo e(trans('label.a_new_model')); ?>" name="name" class="form-control col-md-3 check-exists" disabled="disabled"> 
                    <input type="hidden" id="status" name="active" value="1">
                    <span class="alert-box"></span>
                    <span>
                        <div class="onoffswitch">
                            <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="myonoffswitch" checked>
                            <label class="onoffswitch-label" for="myonoffswitch">
                                <span class="onoffswitch-inner"></span>
                                <span class="onoffswitch-switch active"><i class="hang fas fa-check"></i></span>
                            </label>
                        </div>
                    </span>
                    <span>
                        <input type="submit" class="btn btn-primary" id="add" value="<?php echo e(trans('label.add')); ?>" disabled="disabled">
                    </span>      
                </form>
          	  </div>
      	  </div>
          <!--end box body-->
  		  </div>
        <!--end box col-md-12-->
		</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/public/dist/js/models.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>