<table class="table tablesorter" id="myTable">
<thead>

    <tr>
    <th class="filter-false sorter-false"><input type="checkbox" id="options"></th>
    <th class="sorter-false" data-order="<?php echo e(request()->order === 'desc' ? 'asc' : 'desc'); ?>" href="<?php echo e(url('/sort')); ?>?sort=id&order=">ID</th>
    <th class="sorter-false">Title</th>
    <th class="filter-select filter-onlyAvail sorter-false">Location</th>
    <th class="sorter-false">Registration no.</th>
    <th class="sorter-false">Price (đ)</th>
    <th class="filter-select filter-onlyAvail sorter-false">Status</th>        
    <th class="sorter-false">Date/Time</th>                 
    </tr>
</thead>
<tbody>


<?php foreach($items as $item): ?>

    <tr>
    <th><input class="checkBoxes" type="checkbox" name="checkBoxArray[]" value="<?php echo e($item->id); ?>"></th>
    <th scope="row"><?php echo e($item->id); ?></th>
    <td><?php echo e($item->name); ?></td>
    <td><?php echo e($item->id_province); ?></td>
    <td><?php echo e($item->seri); ?></td>
    <td><?php echo e(number_format($item->price,"0",",",".")); ?> đ</td>
    <td><?php echo e($item->status); ?></td>
    <td><?php echo e($item->date_add); ?></td>
    <td></td>
<?php endforeach; ?>

</tbody>
</table>

<script>

$(function() {

  // call the tablesorter plugin
  $("table").tablesorter({
    theme: 'jui',


    // hidden filter input/selects will resize the columns, so try to minimize the change
    widthFixed : true,

    // initialize zebra striping and filter widgets
    widgets : ["zebra", "filter", "stickyHeaders", "uitheme"],

    //headers: { 0: { sorter: false, filter: false } },

    widgetOptions : {

      // extra css class applied to the table row containing the filters & the inputs within that row
      filter_cssFilter   : '',

      // If there are child rows in the table (rows with class name from "cssChildRow" option)
      // and this option is true and a match is found anywhere in the child row, then it will make that row
      // visible; default is false
      filter_childRows   : false,

      // if true, filters are collapsed initially, but can be revealed by hovering over the grey bar immediately
      // below the header row. Additionally, tabbing through the document will open the filter row when an input gets focus
      filter_hideFilters : false,

      // Set this option to false to make the searches case sensitive
      filter_ignoreCase  : true,

      // jQuery selector string of an element used to reset the filters
      filter_reset : '.reset',

      // Use the $.tablesorter.storage utility to save the most recent filters
      

      // Delay in milliseconds before the filter widget starts searching; This option prevents searching for
      // every character while typing and should make searching large tables faster.
      filter_searchDelay : 300,

      // Set this option to true to use the filter to find text from the start of the column
      // So typing in "a" will find "albert" but not "frank", both have a's; default is false
      filter_startsWith  : false,

      // Add select box to 4th column (zero-based index)
      // each option has an associated function that returns a boolean
      // function variables:
      // e = exact text from cell
      // n = normalized value returned by the column parser
      // f = search filter input value
      // i = column index
      filter_functions : {
        0: {
          sorter: 'checkbox'
        },

    
      },
      

      filter_formatter : {
        7 : function($cell, indx){
          return $.tablesorter.filterFormatter.uiDatepicker( $cell, indx, {
            // from : '08/01/2013', // default from date
            // to   : '1/18/2014',  // default to date
            changeMonth : true,
            changeYear : true
          });
        },
      },
       // added v2.16
       filter_placeholder : {
        from : 'From...',
          to   : 'To...'
        }

    }

  });

});

$(document).ready(function(){
  $('#options').click(function(){
    console.log('clicked');
    if(this.checked){
      $('.checkBoxes').each(function(){
        this.checked = true;
      });
    }else{
      $('.checkBoxes').each(function(){
        this.checked = false;
      });
    }
 
  });

  $("th:not(:first)").on('click',function(){

 
    table = $(this).data("order");
 
    href = $(this).attr("href") + table;

    $.ajax({
      type:"get",
      url: href,
      success : function(data){
        $("table").html(data);
      }
    });
    //window.location.replace(href);
    console.log(href);
  });

});
</script>