<?php
use Carbon\Carbon;

$listUser = array();
if(!$users->isEmpty()){
    $i=0;
    foreach($users as $user)
    {
        if($user->status == 'Banned'){
            $action = '<td><label class="action" style="color:green;cursor:pointer;">Re-active</label></td>';
        }elseif($user->status == 'Active'){
            $action = '<td><label class="action" style="color:red;cursor:pointer;">Ban</label></td>';
        }else{
            $action = '<td></td>';
        }

        $listUser[$i]['id'] = '<td><a href="'.route('admin.accounts.detail',$user->id).'">'.$user->id.'</a></td>';
        $listUser[$i]['phone']= '<td><a href="'.route('admin.accounts.detail',$user->id).'">'.$user->phone.'</a></td>';
        $listUser[$i]['name']= '<td><a href="'.route('admin.accounts.detail',$user->id).'">'.$user->name.'</a></td>';
        $listUser[$i]['items']= $user->items ? count($user->items) : "0";
        $listUser[$i]['underreview']= $user->items ? $user->countItems('Under review') : "0";
        $listUser[$i]['active']= $user->items ? $user->countItems('Active') : "0";
        $listUser[$i]['inactive']= $user->items ? $user->countItems('Inactive') : "0";
        $listUser[$i]['rejected']= $user->items ? $user->countItems('Rejected') : "0";
        $listUser[$i]['cancelled']= $user->items ? $user->countItems('Cancelled') : "0";
        $listUser[$i]['status']= $user->status ? $user->status : "";
        $listUser[$i]['created_at']= $user->created_at ? $user->created_at->format('m/d/Y H:i') : "";
        $listUser[$i]['last_visit']= $user->last_visit ? Carbon::parse($user->last_visit)->format('m/d/Y H:i') : "";

        $listUser[$i]['action'] = $action;
        $listUser[$i]['checkbox'] = '<td><input class="checkBoxes" type="checkbox" name="checkBoxArray[]" value="'.$user->id.'"></td>';
        
        $i++;
    }

}
echo 1;
return $listUser;