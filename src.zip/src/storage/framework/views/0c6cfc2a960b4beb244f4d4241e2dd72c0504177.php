<?php $__env->startSection('content'); ?>

<div class="container" >

    <div class="row">
        <!--box header-->
        <div class="box-header">
          <h3 class="box-title"><a href="<?php echo e(route('admin.items.dashboard')); ?>"><?php echo e(trans('label.administrator')); ?></a> > <b><?php echo e(trans('label.accounts')); ?></b></h3>
        </div>
        <!--end box header-->
        <div class="col-md-12" style="margin-top:30px;">
          
          <div class="box">            
            <!--box body-->
            <div class="box-body" style="background:white;">
              <form action="<?php echo e(route('admin.accounts.bulkupdate')); ?>" method="post" class="form-inline" style="margin-top:30px;background:white;">
                  <?php echo e(csrf_field()); ?>

                  <!--alert-->
                  <?php if(session('alert')): ?>
                      <div id="message" class="alert alert-success"><?php echo e(session('alert')); ?></div>
                  <?php endif; ?>
                  <!--end alert-->
                  <!--Table-->
                  <table id="itemTable" cellpadding="0" cellspacing="0" border="0" class="table table-bordered table-striped" width="100%">
                      <thead class="">
                        <tr>
                            <th>ID</th>
                            <th><?php echo e(trans('label.phone')); ?></th>
                            <th><?php echo e(trans('label.name')); ?></th>
                            <th><?php echo e(trans('label.items')); ?></th>
                            <th><?php echo e(trans('label.under')); ?></th>
                            <th><?php echo e(trans('label.active')); ?></th>
                            <th><?php echo e(trans('label.inactive')); ?></th>
                            <th><?php echo e(trans('label.rejected')); ?></th>
                            <th><?php echo e(trans('label.cancelled')); ?></th>
                            <th><?php echo e(trans('label.status')); ?></th>
                            <th><?php echo e(trans('label.regison')); ?></th>
                            <th><?php echo e(trans('label.lastvisit')); ?></th>
                            <th><?php echo e(trans('label.action')); ?></th>
                            <th><input type="checkbox" id="options" style="margin-left:-7px;"></th>
                        </tr>
                      </thead>
                      <thead>
                        <tr>
                        <td class="width5percent"><input type="text" data-column="0"  class="search-input-text form-control width100percent"></td>
                        <td class="width12percent"><input type="text" data-column="1"  class="search-input-text form-control width100percent"></td>
                        <td class="width12percent"><input type="text" data-column="2"  class="search-input-text form-control width100percent"></td>
                        

                        <td class="width3percent"></td>
                        <td class="width5percent"></td>
                        <td class="width2percent"></td>
                        <td class="width2percent"></td>
                        <td class="width2percent"></td>
                        <td class="width3percent"></td>

                        <td class="width8percent">
                            <select data-column="9"  class="search-input-select form-control width100percent">
                            <option value="">(<?php echo e(trans('label.status')); ?>)</option>
                            
                            <?php foreach($statuses as $key=>$value): ?>
                            <option value="<?php echo e($value); ?>"><?php echo e($value); ?>

                            </option>
                            <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="width5percent">
                            <input type="text" data-column="10" id="dayRegisFrom" placeholder="<?php echo e(trans('label.from')); ?>"  class="search-regis-date form-control width100percent">
                            <input type="text" data-column="10" id="dayRegisTo" placeholder="<?php echo e(trans('label.to')); ?>" class="search-regis-date form-control width100percent">
                        </td>
                        <td class="width5percent">
                            <input type="text" data-column="11" id="dayVisitFrom" placeholder="<?php echo e(trans('label.from')); ?>"  class="search-visit-date form-control width100percent">
                            <input type="text" data-column="11" id="dayVisitTo" placeholder="<?php echo e(trans('label.to')); ?>" class="search-visit-date form-control width100percent">
                        </td>
                        <td class="width1percent"></td>
                        <td class="width1percent"></td>
                        </tr>
                      </thead>
                
                  </table>
                  <!--end table-->
                  <!--Change status-->    
                  <div class="form-group" style="float:right;position:relative;top:-30px;right:-165px"> 
                    <div class="col-md-12"><?php echo e(trans('label.changestatus')); ?></div>
                      <select name="checkBoxes" id="" class="form-control" style="margin-left:15px;">
                        <?php foreach($statuses as $key=>$value): ?>
                        <option value="<?php echo e($value); ?>"><?php echo e($value); ?>

                        </option>
                        <?php endforeach; ?>
                      </select>
                      <input type="submit" class="btn btn-success" value="<?php echo e(trans('label.submit')); ?>">
                    </div>
                  </div>
                  <!--end sttus-->
              </form>
            </div>
            <!--end box body-->
          </div>

        </div>

    </div>   

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/public/dist/js/accounts.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>