<td><a href="'.route('admin.accounts.detail',$user->id).'">1</a></td>+<td><a href="'.route('admin.accounts.detail',$user->id).'">1</a></td>
      
   