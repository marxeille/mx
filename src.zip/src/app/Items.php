<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
abstract class Items extends Model
{
    abstract public function items();
    	//
}
