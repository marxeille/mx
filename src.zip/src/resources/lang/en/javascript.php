<?php
return [
    'name_is_not_valid' => 'Name is not valid. ',
    'confirm_txt' => 'Are you sure to do this ? ',
    'error_msg' => 'Something went wrong , please refresh the page.',
    'items' => 'Items',
    'accounts' => 'Accounts',
    'total_accounts' => 'Total accounts',
    'total_items' => 'Total items',
    'active_items' => 'Active items',
    'active_accounts' => 'Active accounts',
    'active' => 'Active'
];