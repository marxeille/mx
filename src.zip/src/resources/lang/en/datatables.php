<?php 
return [
    'processing' => 'Processing...',
    'empty_table' => 'Empty Table',
    'show' => 'Showing',
    'record' => 'record(s)',
    'first' => 'First',
    'last' => 'Last',
    'next' => 'Next',
    'prev' => 'Prev',
    'filtered' => 'Filtered from',
    'no_record' => 'No record found'
];