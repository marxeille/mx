<?php
return [
    'name_is_not_valid' => 'Tên không hợp lệ.',
    'confirm_txt' => 'Bạn có chắc không ?',
    'error_msg' => 'Có lỗi xảy ra , vui lòng tải lại trang.',
    'items' => 'Bài đăng',
    'accounts' => 'Tài khoản',
    'total_accounts' => 'Tất cả tài khoản',
    'total_items' => 'Tất cả bài đăng',
    'active_items' => 'Bài đăng được kích hoạt',
    'active_accounts' => 'Tài khoản được kích hoạt',
    'active' => 'Đã kích hoạt'
];